import java.util.Scanner;
public class Student extends Hostel implements Department
{
	String sName,regNo,eleSub;
	String deptName,deptHead;
	int avgMarks;
	public void getStudentName()
	{
		System.out.println("Student: "+sName);
	}
	public String getStudentRegNo()
	{
		return regNo;
	}
	public void getElectiveSubject()
	{
		System.out.println("Elective Subject: "+ eleSub);
	}
	public void getAvgMarks()
	{
		System.out.println("Average Marks: " + avgMarks);
	}
	public void getDeptName()
	{
		System.out.println("Department Name: "+deptName);
	}
	public void getDeptHead()
	{
		System.out.println("Department Name: "+ deptHead);
	}
	public void addStudent()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Student Name: ");
		sName = sc.nextLine();
		System.out.print("Enter Student Registrarion Number: ");
		regNo = sc.nextLine();
		System.out.print("Enter Elective Subject: ");
		eleSub = sc.nextLine();
		System.out.print("Enter Hostel Name: ");
		hName = sc.nextLine();
		System.out.print("Enter Hostel Location: ");
		hLocation = sc.nextLine();
		System.out.print("Enter Department Name: ");
		deptName = sc.nextLine();
		System.out.print("Enter Department Head: ");
		deptHead = sc.nextLine();
		System.out.print("Enter No. Of Rooms: ");
		noOfRoom = sc.nextInt();
		System.out.print("Enter Avg. Marks: ");
		avgMarks = sc.nextInt();
	}
	public void migrate()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Department name: ");
		deptName = sc.nextLine();
		System.out.print("Enter Department Head: ");
		deptHead = sc.nextLine();
	}
	public void display()
	{
		getStudentName();
		System.out.println("Student Registration No is: "+ getStudentRegNo());
		getElectiveSubject();
		getAvgMarks();
		getDeptName();
		getDeptHead();
	}
}
