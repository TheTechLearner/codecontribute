public class Hostel 
{
	protected String hName,hLocation;
	int noOfRoom;
	public void getHostelName()
	{
		System.out.println("Name of the Hostel: "+ hName);
	}
	public void getHostelLocation()
	{
		System.out.println("Hostel: " + hLocation);
	}
	public void getNoOfRoom()
	{
		System.out.println("Total Room: " + noOfRoom);
	}	
}
