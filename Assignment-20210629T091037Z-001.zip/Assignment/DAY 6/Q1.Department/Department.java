public interface Department 
{
	public void getDeptName();
	public void getDeptHead();
}
