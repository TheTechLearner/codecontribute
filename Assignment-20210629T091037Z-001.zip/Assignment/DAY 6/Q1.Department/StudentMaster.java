import java.util.Scanner;
public class StudentMaster 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Student stud[] = new Student[100];
		int sno = 0,ch;
		String rno;
		boolean b;
		while (true)
		{
			System.out.println("\n1. Admit a Student");
			System.out.println("2. Migrate A Student");
			System.out.println("3. Display");
			System.out.println("4. Exit");
			System.out.print("Enter Your Choice: ");
			ch = sc.nextInt();
			switch(ch)
			{
				case 1: stud[sno] = new Student();
						stud[sno++].addStudent();
						break;
				case 2: System.out.print("Enter Registration No.: ");
						rno = sc.next();
						b = false;
						for (int i=0; i<sno; i++)
						{
							if (stud[i].getStudentRegNo().equals(rno))
							{
								b = true;
								stud[i].migrate();
								break;
							}
						}
						if (b == false)
						{
							System.out.println("Student Not Found");
						}
						break;
				case 3: System.out.print("Enter Registration No.: ");
						rno = sc.next();
						b = false;
						for (int i=0; i<sno; i++)
						{
							if (stud[i].getStudentRegNo().equals(rno))
							{
								b = true;
								stud[i].display();
								break;
							}
						}
						if (b == false)
						{
							System.out.println("Student Not Found");
						}
						break;
				case 4: System.exit(0);
				default: System.out.println("Wrong Choice");
			}
		}
	}

}
