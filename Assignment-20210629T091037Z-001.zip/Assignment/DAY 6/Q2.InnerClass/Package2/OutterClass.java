package Package2;
import Package1.*;
public class OutterClass 
{
	protected class InnerClass implements Interface1
	{
		public InnerClass() {
		}
		@Override
		public void greeting()
		{
			System.out.println(" Hello! ");
		}
		@Override
		public void farewell()
		{
			System.out.println(" Farewell! ");
		}
	}
}
