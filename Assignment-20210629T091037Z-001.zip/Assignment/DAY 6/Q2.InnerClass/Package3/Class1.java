package Package3;
import Package1.*;
import Package2.*;

public class Class1 extends OutterClass 
{
	public Interface1 method1()
	{
		OutterClass.InnerClass inObj = new OutterClass.InnerClass();
		return inObj;
	}
	public static void main(String[] args)
	{
		Class1 obj = new Class1();
		obj.method1().greeting();
		obj.method1().farewell();
	}
}