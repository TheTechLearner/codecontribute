package Package1;
public interface Interface1 
{
	public void greeting();
	public void farewell();
}
