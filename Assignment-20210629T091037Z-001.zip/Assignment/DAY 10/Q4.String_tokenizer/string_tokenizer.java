import java.util.*;

class string_tokenizer
{
	public static void main(String[] args) 
    {	
		System.out.println("Enter String ");

		Scanner e=new Scanner(System.in);
		String S= e.nextLine();

		System.out.println("THE GIVEN STRING IS :: "+S);
		StringTokenizer st= new StringTokenizer(S);
		
		TreeSet <String> T= new TreeSet<String>();

		while(st.hasMoreTokens())
		{
			T.add(st.nextToken());
		}		
		System.out.println("\nTHE TREE SET IS :: "+T);
	}
}
/*
Enter String
Angadraj
THE GIVEN STRING IS :: Angadraj

THE TREE SET IS :: [Angadraj]


*/
