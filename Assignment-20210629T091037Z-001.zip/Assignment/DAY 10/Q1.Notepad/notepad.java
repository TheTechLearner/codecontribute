class notepad extends Thread
{
	public static void main(String[] args) 
    {		
	    int i = 0;
		while( i<3) 
		{        //for infinite time execution we have to add while(true)			
			try
			{
                Process P=Runtime.getRuntime().exec("Notepad");
                Thread.sleep(1000);
		    }
			catch(Exception e) {}
              i++;
		}
	}
}