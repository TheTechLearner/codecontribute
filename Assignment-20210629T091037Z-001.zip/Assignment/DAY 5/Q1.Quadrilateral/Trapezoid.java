
public class Trapezoid extends Quadrilateral
{
	private double height;
	Trapezoid(double x1,double y1,double x2,double y2,double x3,double y3,double x4, double y4,double height)
	{
		super(x1,y1,x2,y2,x3,y3,x4,y4);
		this.height = height;
	}
	public void area()
	{
		double d1 = Math.sqrt((getX1() - getX2())*(getX1() - getX2())+(getY1() - getY2())*(getY1() - getY2()));
		double d2 = Math.sqrt(((getX3() - getX4())*(getX3() - getX4()))+ ((getY3() - getY4())*(getY3() - getY4())));
		double d3 =((d1 + d2)/2)*height; 
		setArea(d3);
	}
	@Override
	public String toString()
	{
		return String.format("%s",super.toString());
	}
}
