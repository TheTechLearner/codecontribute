public class Vehicle 
{
	protected String regnNumber;
	protected double speed;
	protected String color;
	protected String ownerName;
	Vehicle(String regnNumber,double speed,String color,String ownerName)
	{
		this.regnNumber = regnNumber;
		this.speed = speed;
		this.color = color;
		this.ownerName = ownerName;
	}
	public void showData()
	{
		System.out.print("This is a Vehicle Class ");
	}
	@Override
	public String toString()
	{
		return String.format("%s: %s%n%s: %.1f%n%s: %s%n%s: %s","Registered Number",regnNumber,"Speed",speed,"Color",color,"Owner Name",ownerName);
	}
}
