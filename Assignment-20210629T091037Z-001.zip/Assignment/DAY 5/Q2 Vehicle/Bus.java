public class Bus extends Vehicle
{
	private String routeNumber;
	Bus(String regnNumber, double speed, String color,String ownerName, String routeNumber)
	{
		super(regnNumber,speed,color,ownerName);
		this.routeNumber = routeNumber;
	}
	@Override
	public void showData()
	{
		super.showData();
		System.out.println("For Bus");
		System.out.printf("%s%n%s",super.toString(),toString());	
	}
	@Override
	public String toString()
	{
		return String.format("%s%n%s: %s%n",super.toString(),"Route Number",routeNumber);
	}
}
