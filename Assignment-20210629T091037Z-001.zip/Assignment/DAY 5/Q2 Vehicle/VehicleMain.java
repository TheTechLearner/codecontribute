public class VehicleMain 
{
	public static void main(String[] args) 
	{
		Car c = new Car("WB26BJ8814",100,"Red","XYZ","ABC");
		Bus b = new Bus("WB10H5682",100,"Blue","Mr. B","VS2");
		c.showData();
		System.out.printf("%n%n");
		b.showData();
	}

}
