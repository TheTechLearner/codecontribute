public class Car extends Vehicle
{
	private String manufacturerName;
	Car (String regnNumber,double speed,String color,String ownerName,String manufacturerName)
	{
		super(regnNumber,speed,color,ownerName);
		this.manufacturerName = manufacturerName;
	}
	@Override
	public void showData()
	{
		super.showData();
		System.out.println("For Car");
		System.out.printf("%s%n%s",super.toString(),toString());
	}
	@Override
	public String toString()
	{
		return String.format("%s%n%s: %s",super.toString(),"Manufacturer Name",manufacturerName);
	}
}
