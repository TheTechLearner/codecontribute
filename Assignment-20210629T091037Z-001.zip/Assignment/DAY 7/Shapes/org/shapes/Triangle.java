package org.shapes;
import ioPackage.*;
public class Triangle 
{
	public static double side1,side2,side3;
	private static input_output io = new input_output();	
	public static void setSides()
	{
		side1 = io.input("Enter length of 1st side of Triangle: ");
		side2 = io.input("Enter length of 2nd side of Triangle: ");
		side3 = io.input("Enter length of 3rd side of Triangle: ");
	}
	public static double getSide1()
	{
		return side1;
	}
	public static double getSide2()
	{
		return side2;
	}
	public static double getSide3()
	{
		return side3;
	}
	public static void display()
	{
		io.output("Sides of the triangle are", side1,side2,side3);
	}
	public static double area()
	{
		setSides();
		double s = parameter()/2;
		double area = Math.sqrt(s*((s-side1)*(s-side2)*(s-side3)));
		return area;
	}
	public static double parameter()
	{
		double para;
		para = (side1 + side2 + side3);
		return para;
	}
}
