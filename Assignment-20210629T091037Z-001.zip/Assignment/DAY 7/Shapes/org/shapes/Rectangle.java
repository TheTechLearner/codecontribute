package org.shapes;
import ioPackage.*;
public class Rectangle
{
	private static double l,b;
	private static input_output io = new input_output();
	public static void setLB()
	{
		l = io.input("Enter Length: ");
		b = io.input("Enter Breadth: ");
	}
	public static double getL()
	{
		return l;
	}
	public static double getB()
	{
		return b;
	}
	public static void area()
	{
		setLB();
		double area = l * b;
		io.output("Area of Rectangle", area);
	}
	public static void parameter()
	{
		double para = 2 * (l + b);
		io.output("Parameter of a rectangle" , para);
	}
}
