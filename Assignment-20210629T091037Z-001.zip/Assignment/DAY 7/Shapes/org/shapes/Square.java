package org.shapes;
import ioPackage.*;
public class Square 
{
	private static double side;
	private static input_output io = new input_output();	
	public static void setSide()
	{
		side = io.input("Enter Side of a Square: ");
	}
	public static double getSide()
	{
		return side;
	}
	public static void area()
	{
		setSide();
		double area = getSide() * getSide();
		io.output("area of square",area);
	}
	public static void parameter()
	{
		double para = 4 * getSide();
		io.output("Parameter of Square is",para);
	}
}