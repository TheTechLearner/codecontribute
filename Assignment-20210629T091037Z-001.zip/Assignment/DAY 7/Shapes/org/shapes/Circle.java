package org.shapes;
import ioPackage.*;
public class Circle
{
	public static double radius;
	private static input_output io = new input_output();	
	public static void setRadius()
	{
		radius = io.input("Enter Radius of a Circle: ");
	}
	public static double getRadius()
	{
		return radius;
	}
	public void display()
	{
		io.output("Radius of a circle is", getRadius());
	}
	public static void area()
	{
		setRadius();
		double area =Math.PI * Math.pow(radius,2);
		io.output("Area of Circle is",area);
	}
	public static void circumference()
	{
		double circumference = 2 * Math.PI * radius;
		io.output("Circumference of a circle is", circumference);
	}
}