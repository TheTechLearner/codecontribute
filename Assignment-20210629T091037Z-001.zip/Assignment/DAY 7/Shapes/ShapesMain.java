import ioPackage.*;
import org.shapes.*;
public class ShapesMain
{
	public static void main(String[] args) 
	{
		int ch;
		do 
		{
			input_output io = new input_output();
			System.out.println("1. Square.");
			System.out.println("2. Triangle.");
			System.out.println("3. Circle.");
			System.out.println("4. Rectangle.");
			System.out.println("5. Exit.");
			ch = (int)(io.input("Enter your choice: "));
			switch(ch)
			{
				case 1: Square.area();
						Square.parameter();
						break;
				case 2: double area = Triangle.area();
						double para = Triangle.parameter();
						io.output("Area and Parameter of Triangle is", area,para);
						break;
				case 3: Circle.area();
						Circle.circumference();
						break;
				case 4: Rectangle.area();
						Rectangle.parameter();
						break;
			}
			System.out.println();
		}while(ch != 5);
		System.out.println("Thank You");
	}
}