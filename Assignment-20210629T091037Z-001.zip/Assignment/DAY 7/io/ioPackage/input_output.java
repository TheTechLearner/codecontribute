package ioPackage;
import java.util.Scanner;
public class input_output 
{
	private Scanner sc;
	public  double input(String message)
	{
		double a;
		sc = new Scanner(System.in);
		System.out.print(message);
		a = sc.nextDouble();
		return a;
	}
	public void output(String message,double ...a)//variable length parameter
	{
		System.out.print(message+": ");
		for (double i : a)
		{
			System.out.printf("%.2f ",i);
		}
		System.out.println();
	}
}
