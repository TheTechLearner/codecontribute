import java.util.Scanner;
public class Str_Q6 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter String: ");
		String str = sc.nextLine(), str2;
		int i,upCase = 0, loCase = 0, spaces = 0;
		for (i = 0; i<str.length();i++)
		{
			if (str.charAt(i) >= 'a' && str.charAt(i) <= 'z')
				loCase++;
			else if(str.charAt(i) >= 'A' && str.charAt(i) <= 'Z')
				upCase++;
			else if (str.charAt(i) == ' ')
				spaces++;
		}
		System.out.print("Enter a String to search: ");
		str2 = sc.nextLine();
		System.out.printf("No. of Uppercase Character: %d%nNo. of Lowercase Character: %d%nSearch status: ",upCase,loCase);
		if (str.contains(str2))
			System.out.print("Found");
		else
			System.out.print("Not Found");
		System.out.printf("%nNo. of Spaces:%d ",spaces);
		sc.close();
	}

}
