
public class Time {
	int  hours, minutes, seconds;
	Time()
	{
		hours = 0;
		minutes = 0;
		seconds = 0;
	}
	Time(int hours,int minutes, int seconds)
	{
		this.hours = hours;
		this.minutes = minutes;
		this.seconds = seconds;
	}
	public void setHours(int hours)
	{
		this.hours = hours;
	}
	public void setMinutes(int minutes)
	{
		this.minutes = minutes;
	}
	public void setSeconds(int seconds)
	{
		this.seconds = seconds;
	}
	public int getHours()
	{
		return hours;
	}
	public int getMinutes()
	{
		return minutes;
	}
	public int getSeconds()
	{
		return seconds;
	}
	public static void addTimes(Time obj1,Time obj2)
	{
		Time obj3 = new Time();
		obj3.seconds = obj1.seconds + obj2.seconds;
		obj3.minutes = obj1.minutes + obj2.minutes + (obj3.seconds/60);
		obj3.hours = obj1.hours + obj2.hours + (obj3.minutes/60);
		obj3.minutes = obj3.minutes % 60;
		obj3.seconds = obj3.seconds % 60;
		obj3.display();
	}
	Time greater_time(Time t1,Time t2)
	{
		if(t1.hours >t2.hours)
			return t1;
		else if(t1.hours < t2.hours)
			return t2;
		else
		{
			if(t1.minutes > t2.minutes)
				return t1;
			else if(t1.minutes < t2.minutes)
				return t2;
			else
			{
				if(t1.seconds > t2.seconds)
					return t1;
				else if(t2.seconds < t2.seconds)
					return t2;
				else 
					return t1;
			}
		}
	}
	public void display()
	{
		if (this.hours < 10)
		{
			System.out.print("0"+this.hours);
		}
		else
		{
			System.out.print(this.hours);
		}
		if (this.minutes < 10)
		{
			System.out.print(":0"+this.minutes);
		}
		else
		{
			System.out.print(":"+this.minutes);
		}
		if (this.seconds < 10)
		{
			System.out.print(":0"+this.seconds);
		}
		else
		{
			System.out.print(":"+this.seconds);
		}

	}
}

