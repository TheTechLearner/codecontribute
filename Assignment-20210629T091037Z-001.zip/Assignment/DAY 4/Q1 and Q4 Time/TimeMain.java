import java.util.*;
public class TimeMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Time t[] = new Time[3];
		int h,m,s;
		for (int i = 1; i <= 2; i++)
		{
			System.out.println("Enter Time "+i);
			System.out.print("Enter Hours: ");
			h = sc.nextInt();
			System.out.print("Enter Minutes: ");
			m = sc.nextInt();
			System.out.print("Enter Seconds: ");
			s = sc.nextInt();
			t[i-1] = new Time(h, m, s);
		}
		t[0].display();
		System.out.println();
		t[1].display();
		System.out.println();
		t[2] = new Time();
		Time.addTimes(t[0], t[1]);
		System.out.println();
		t[2] = t[0].greater_time(t[0],t[1]);
		System.out.print("Greater Time is: ");
		t[2].display();
		sc.close();

	}

}
