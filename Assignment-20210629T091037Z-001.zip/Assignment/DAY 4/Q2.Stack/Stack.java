public class Stack 
{
	private int n;
	private int arr[];
	private int top;
	Stack(int n)
	{
		this.n = n;
		this.arr = new int[this.n];
		this.top = -1;
	}
	public int counts()
	{
		int count = 0;
		for (int i = 0; i < n; i++)
		{
			if (arr[i] == 0)
			{
				break;
			}
			count++;
		}
		return count;
	}
	public boolean isFull()
	{
		if (top == n-1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean isEmpty()
	{
		if (top == -1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public void push(int num)
	{
		if (!isFull())
		{
			this.top++;
			this.arr[this.top] = num;
		}
		else
		{
			System.out.println("OverFlow");
		}
	}
	public void pop()
	{
		if (!isEmpty())
		{
			System.out.println("Popped Element is "+this.arr[this.top--]);
		}
		else
		{
			System.out.println("UnderFlow");
		}
	}
	public void display()
	{
		if (!isEmpty())
		{
			System.out.print("Stack is: ");
			for (int i = n-1; i >= 0; i--)
			{
				if (arr[i] != 0)
					System.out.print(" "+arr[i]+" ");
			}
			System.out.println("");
		}
	}
}
