import java.util.Scanner;
public class StackMain 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int size,choice,choice1,num;
		char ch;
		System.out.print("Enter size of 1st stack: ");
		size = sc.nextInt();
		Stack s1 = new Stack(size);
		System.out.print("Enter size of 2nd stack: ");
		size = sc.nextInt();
		Stack s2 = new Stack(size);
		boolean conti = true, conti1 = true;
		while (conti)
		{
			conti1 = true;
			System.out.println("1. Enter on 1st Stack");
			System.out.println("2. Enter on 2nd Stack");
			System.out.print("Enter Your Choice: ");
			choice = sc.nextInt();
			switch(choice)
			{
				case 1: while (conti1) 
						{
							System.out.println("1. Push");
							System.out.println("2. Pop");
							System.out.println("3. Display");
							System.out.println("Enter Your Choice: ");
							choice1 = sc.nextInt();
							switch(choice1)
							{
					   			case 1: System.out.println("Enter Number: ");
					   					num = sc.nextInt();
					   					s1.push(num);
					   					break;
					   			case 2: s1.pop();
					   					break;
					   			case 3: s1.display();
					   					break;
							}
							if (s1.counts() == s2.counts())
							{
								System.out.println("No of Element in\n 1st stack : "+s1.counts()+"\n 2nd stsck: "+s2.counts());
							}
							System.out.print("Do You want to continue on 1st Stack(y/n):");
							ch = sc.next().charAt(0);
							if (ch == 'y' || ch == 'Y')
								conti1 = true;
							else
								conti1 = false;
						}
						break;
				case 2:	while (conti1) 
						{
							System.out.println("1. Push");
							System.out.println("2. Pop");
							System.out.println("3. Display");
							System.out.println("Enter Your Choice: ");
							choice1 = sc.nextInt();
							switch(choice1)
							{
			    				case 1: System.out.println("Enter Number: ");
			    						num = sc.nextInt();
			    						s2.push(num);
			    						break;
			    				case 2: s2.pop();
			   							break;
			    				case 3: s2.display();
			   							break;
							}
							if (s1.counts() == s2.counts())
							{
								System.out.println("No of Element in\n 1st stack : "+s1.counts()+"\n 2nd stsck: "+s2.counts());
							}
							System.out.print("Do You want to continue on 1st Stack(y/n):");
							ch = sc.next().charAt(0);
							if (ch == 'y' || ch == 'Y')
								conti1 = true;
							else
								conti1 = false;
						}
			    		break;
			    default: System.out.println("Wrong Choice");
			}
			System.out.println("Do You want to continue(y/n): ");
			ch = sc.next().charAt(0);
			if (ch == 'y')
			{
				conti = true;
			}
			else
			{
				conti = false;
			}
		}
		sc.close();
	}
}
