
public class PingPongMain 
{
	public static void main(String[] args) throws InterruptedException 
	{
		PingThread pt = new PingThread("Ping");
		PongThread pot = new PongThread("Pong");
		
		pt.start();
		Thread.sleep(100);
		pot.start();
	}

}
