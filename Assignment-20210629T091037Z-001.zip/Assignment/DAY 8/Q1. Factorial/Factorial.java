import java.util.Scanner;

public class Factorial 
{
	public static long facto(int num)
	{
		if (num < 0)
			throw new IllegalArgumentException("Value of num must be positive");
		else
		{
			long f = 1;
			for (int i = 1;i<=num;i++)
			{
				if (f*i < 0)
					throw new IllegalArgumentException("Result OverFlow");
				f=f*i;
			}
			return f;
		}
	}
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		boolean continueloop = true;
		do
		{
			try 
			{
				System.out.print("Enter x: ");
				int x = sc.nextInt();
				long num = facto(x);
				System.out.println("Factorial of "+x+": "+num);
				continueloop = false;
			}
			catch (IllegalArgumentException ex)
			{
				System.out.println("Exception: "+ex.getMessage());
				System.out.println("");
			}
		}while (continueloop);
		sc.close();
	}
}
