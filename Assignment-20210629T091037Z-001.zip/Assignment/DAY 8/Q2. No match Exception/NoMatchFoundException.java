public class NoMatchFoundException extends Exception
{
	public NoMatchFoundException(String s) 
    { 
        super(s); 
    }
}
