import java.util.Scanner;
public class NoMatchFoundExceptionMain 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		try
		{
			System.out.print("Enter A String: ");
			String str = sc.nextLine();
			if (str.equals("University"))
			{
				System.out.println("Equal");
			}
			else 
			{
				throw new NoMatchFoundException(""+str+" != University");
			}
		}
		catch (NoMatchFoundException ex)
		{
			System.out.println("Exception: "+ex.getMessage());
		}
	}
}
